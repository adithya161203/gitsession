# -*- coding: utf-8 -*-

from odoo import _, api, fields, models
from datetime import timedelta


class StockWarehouseOrderPoint(models.Model):
    """ Inherited stock.warehouse.orderpoint to add monthly_usage and minimum_month_stock field in replinishment"""
    _inherit = 'stock.warehouse.orderpoint'

    monthly_usage = fields.Float(string='Monthly Usage', compute='_compute_monthly_usage')
    minimum_month_stock = fields.Float(string='Minimum Month Stock')

    @api.depends('minimum_month_stock')
    def _compute_monthly_usage(self):
        ninety_days_ago = fields.Datetime.now() - timedelta(days=90)

        for rec in self:
            if not rec.product_id:
                rec.monthly_usage = 0
                continue  # Skip records without a product

            # Search for stock moves linked to outgoing stock pickings in the last 90 days
            stock_moves = self.env['stock.move'].search([
                ('picking_id.picking_type_code', '=', 'outgoing'),
                ('create_date', '>=', ninety_days_ago),
                ('product_id', '=', rec.product_id.id)
            ])

            # Search for MRP productions in the last 90 days
            mrp_productions = self.env['mrp.production'].search([
                ('product_id', '=', rec.product_id.id),
                ('create_date', '>=', ninety_days_ago)
            ])

            # Compute total quantity from stock moves and MRP productions
            total_quantity = sum(stock_moves.mapped('quantity')) + sum(mrp_productions.mapped('product_qty'))

            # Compute monthly usage (divide by 3 to get the monthly average)
            rec.monthly_usage = total_quantity / 3 if total_quantity else 0
            rec.product_min_qty = rec.monthly_usage * rec.minimum_month_stock
