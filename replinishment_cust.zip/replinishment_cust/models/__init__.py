# -*- coding: utf-8 -*-

from . import stock_warehouse_orderpoint