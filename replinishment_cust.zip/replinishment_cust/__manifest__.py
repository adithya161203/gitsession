# -*- coding: utf-8 -*-

{
    'name': "Replishment cust",
    'version': '18.0.1.0.0',
    'application': True,

    'depends': [
        'base',
        'stock',
        'mrp'
    ],

    'data': [
        'views/replishment_view.xml',
    ]
}
