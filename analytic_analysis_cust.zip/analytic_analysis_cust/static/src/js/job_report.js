/** @odoo-module */
import { registry} from '@web/core/registry';
import { useService } from "@web/core/utils/hooks";
const { Component, mount} = owl
export class JobReport extends Component {
	setup(){
    	this.action = useService("action");
    	this.rpc = this.env.services.rpc
	}
//	loadData(){
//    	let self = this;
//     	rpc.query({
//        	model: 'partner.dashboard',
//        	method: 'get_values',
//        	args:[]
//        	}).then(function(data){
//            	console.log(data, 'dataaaa')
//            	self.AdvancedDashboard.data = data;
//    	});
//	}
}
JobReport.template = "job.report"
registry.category("actions").add("job_report", JobReport)