# -*- coding: utf-8 -*-

{
    'name': "Analytic Analysis Cust",
    'version': '18.0.1.0.1',
    'application': True,
    'depends': [
        'base',
        'account',
        'accountant',
        'stock',
        'account_accountant',
        'track_location_analytics',
    ],
    'data': [
        'views/settings_view.xml',
        'views/report_action_view.xml',

    ],
    'assets': {
        'web.assets_backend': [
            'analytic_analysis_cust/static/src/js/job_report.js',
            'analytic_analysis_cust/static/src/xml/job_report.xml',
        ],
    },
}
