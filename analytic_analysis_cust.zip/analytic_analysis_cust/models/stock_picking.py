# -*- coding: utf-8 -*-

from odoo import models, Command


class StockPicking(models.Model):
    """
       Inherits stock.picking to enhance the validation process by
       automatically adjusting analytic accounting entries when analytic
       tracking is enabled in the company settings.
       """

    _inherit = 'stock.picking'

    def button_validate(self):
        res = super().button_validate()

        company = self.env.company
        if not company.is_analytic_enabled or not self.analytic_account:
            return res

        move_ids = self.move_line_ids.mapped('move_id.id')
        if not move_ids:
            return res

        account_moves = self.env['account.move'].search([('stock_move_id', 'in', move_ids)], limit=1)
        valuation_layer = self.env['stock.valuation.layer'].search([('stock_move_id', 'in', move_ids)], limit=1)

        if not account_moves or not valuation_layer:
            return res

        material_value = valuation_layer.value * (1 + company.overhead_percentage)

        account_moves.write({
            'state': 'draft',
            'line_ids': [
                Command.clear(),
                Command.create({
                    'move_id': account_moves.id,
                    'name': 'Additional Entry',
                    'account_id': company.stock_valuation_acc.id,
                    'debit': 0.0,
                    'credit': valuation_layer.value,
                    'partner_id': account_moves.partner_id.id if account_moves.partner_id else False,
                }),
                Command.create({
                    'move_id': account_moves.id,
                    'name': 'Additional Entry',
                    'account_id': company.stock_interim_instead.id,
                    'debit': material_value,
                    'credit': 0,
                    'partner_id': account_moves.partner_id.id if account_moves.partner_id else False,
                    'analytic_distribution': account_moves.stock_move_id.analytic_distribution,
                }),
                Command.create({
                    'move_id': account_moves.id,
                    'name': 'Additional Entry',
                    'account_id': company.overhead_acc.id,
                    'debit': 0,
                    'credit': valuation_layer.value * company.overhead_percentage,
                    'partner_id': account_moves.partner_id.id if account_moves.partner_id else False,
                }),
            ]
        })
        account_moves.state = 'posted'

        return res
