# -*- coding: utf-8 -*-

from odoo import  fields, models


class ResCompany(models.Model):
    """
    Inherits `res.company` to introduce additional fields for managing
    stock valuation adjustments with analytic distribution support.
    """

    _inherit = 'res.company'

    overhead_percentage = fields.Float(
        string='Overhead Percentage',
        default=0.1,
        help="Defines the percentage of overhead cost to be applied to stock valuation."
    )

    stock_interim_instead = fields.Many2one(
        'account.account',
        string='Stock Interim Instead',
        help="The account used for interim stock valuation adjustments."
    )

    stock_valuation_acc = fields.Many2one(
        'account.account',
        string='Stock Valuation',
        help="The account where stock valuation entries are recorded."
    )

    overhead_acc = fields.Many2one(
        'account.account',
        string='Overhead Account',
        help="The account used to track overhead costs related to stock valuation."
    )

    is_analytic_enabled = fields.Boolean(
        string='Analytic delivery',
        help="Indicates whether analytic accounting is enabled for stock operations."
    )
