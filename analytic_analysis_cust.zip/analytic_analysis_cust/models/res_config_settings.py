# -*- coding: utf-8 -*-

from odoo import fields, models


class ResConfigSettings(models.TransientModel):
    """
    Inherits `res.config.settings` to provide a configuration interface
    for managing stock valuation and analytic accounting settings at the
    company level.
    """

    _inherit = 'res.config.settings'

    overhead_percentage = fields.Float(
        string='Overhead Percentage',
        related='company_id.overhead_percentage',
        readonly=False,
        help="Defines the percentage of overhead cost to be applied to stock valuation."
    )

    stock_interim_instead = fields.Many2one(
        'account.account',
        string='Stock Interim Instead',
        related='company_id.stock_interim_instead',
        readonly=False,
        help="The account used for interim stock valuation adjustments."
    )

    stock_valuation_acc = fields.Many2one(
        'account.account',
        string='Stock Valuation',
        related='company_id.stock_valuation_acc',
        readonly=False,
        help="The account where stock valuation entries are recorded."
    )

    overhead_acc = fields.Many2one(
        'account.account',
        string='Overhead Account',
        related='company_id.overhead_acc',
        readonly=False,
        help="The account used to track overhead costs related to stock valuation."
    )

    is_analytic_enabled = fields.Boolean(
        string='Is Analytic Enabled',
        related='company_id.is_analytic_enabled',
        readonly=False,
        help="Indicates whether analytic accounting is enabled for stock operations."
    )
