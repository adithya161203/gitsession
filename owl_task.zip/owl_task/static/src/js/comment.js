/** @odoo-module */
import { registry } from "@web/core/registry";
import {Component,onWillStart} from "@odoo/owl";
import { user } from "@web/core/user";
import { useService } from "@web/core/utils/hooks";
import { useState, useRef } from "@odoo/owl";
import { CommentBox} from "./comment_box";
import { useBus } from "@web/core/utils/hooks";
import { useSubEnv,EventBus } from "@odoo/owl";


//import { Component, onWillStart, useEffect } from "@odoo/owl";

class PhotoComment extends Component {
 setup() {
        this.orm = useService('orm')
         this.state = useState({
            input_comment: "",
            comments:{},
            test_model:'',
            lazy:'',
        });
//          setInterval(() => {
//            this.fetchData();
//        }, 900);
         this.busService = this.env.services.bus_service;
         this.channel = 'Hello'
         this.busService.addChannel(this.channel)
        this.busService.subscribe("notification", this.fetchData.bind(this))
        useBus(this.env.bus, 'adithya', (ev) => this.ActionRep(ev))
        useSubEnv({
               key1: new EventBus()
        })
        };
    ActionPost(){
    this.orm.call("photo.comment","post_comment");
    };
    ActionEdit(id){
    console.log("edit")
    }
    ActionDelete(id){
    console.log("del")
    }

    ActionRep(ev){
    console.log("ffe", ev)
    }
async fetchData(){
     console.log("heloo machu", this.state.lazy)
     this.state.comments = await this.orm.searchRead("photo.comment",[],['user_id',"comment"])
}
inputField(ev){
console.log(ev)
}

}
PhotoComment.template = "owl_task.photo_comment"
PhotoComment.components = {
    CommentBox
}
registry.category("actions").add("photo_comment",PhotoComment)