/** @odoo-module */
import { registry } from "@web/core/registry";
import { Component,} from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";
import { useState, useRef } from "@odoo/owl";

export class CommentBox extends Component {
setup() {
         super.setup();
         this.orm = useService('orm')
         this.state = useState({
         comments: "",
        });
        console.log(this.props.value)
        };

    ActionReply(){
      console.log("reply", this.env)
      this.env.bus.trigger('adithya', {
          key:'value',
      });
    }

        }
CommentBox.props = {
 value : { type: Object ,optional:true},
 ActionEdit : {type: Function,optional:true},
 ActionDelete: {type: Function, optional:true}
}
CommentBox.template = "owl_task.comment_box"
