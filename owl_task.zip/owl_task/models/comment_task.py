from odoo import api,models, fields

class PhotoComment(models.Model):
    """
    photo comment model
    """
    _name= "photo.comment"

    user_id = fields.Many2one("res.users",string="Username")
    parent_id = fields.Many2one("photo.comment")
    comment = fields.Text("Comment")
    # likes = fields.Integer("Likes")
    # dislikes = fields.Integer("Comments")

    @api.model
    def post_comment(self):
        channel = 'Hello'
        self.env["bus.bus"]._sendone(channel, 'notification', {})

