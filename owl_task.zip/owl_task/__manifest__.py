{
    'name': 'Photo Comment',
    'sequence': -1,
    'summary': "",
    'description': " ",
    'depends': ['base',
                'web'],
     'data': [
        "security/ir.model.access.csv",
        'views/comment_views.xml',
    ],
    'assets':{
        'web.assets_backend':[
            'owl_task/static/src/js/**',
            'owl_task/static/src/xml/**',
        ]
    }
    }
